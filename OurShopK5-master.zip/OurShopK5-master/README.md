# OurShopK5
eShop Project K5

## Buổi 1:
- Thiết kế layout FrontEnd
- Thiết kế Model Loai, HangHoa
