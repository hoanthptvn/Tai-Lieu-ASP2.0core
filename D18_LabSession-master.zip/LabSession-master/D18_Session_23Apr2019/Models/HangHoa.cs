﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace D18_Session_23Apr2019.Models
{
    public class HangHoa
    {
        public int HangHoaId { get; set; }
        public string TenHangHoa { get; set; }
        public double DonGia { get; set; }
    }
}
